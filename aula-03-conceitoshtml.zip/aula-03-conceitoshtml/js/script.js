console.log('Esta funcionando o console log');
